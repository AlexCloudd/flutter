import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => NotesProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class Note {
  String title;
  String content;

  Note({required this.title, required this.content});

  Note copyWith({String? title, String? content}) {
    return Note(
      title: title ?? this.title,
      content: content ?? this.content,
    );
  }
}

class NotesProvider extends ChangeNotifier {
  List<Note> _notes = [
    Note(title: "Заметка 1", content: "Текст заметки 1"),
    Note(title: "Заметка 2", content: "Текст заметки 2"),
  ];

  List<Note> get notes => _notes;

  void addNote(Note note) {
    _notes.add(note);
    notifyListeners();
  }

  void deleteNote(int index) {
    _notes.removeAt(index);
    notifyListeners();
  }

  void updateNote(int index, Note note) {
    _notes[index] = note;
    notifyListeners();
  }

  void reorderNotes(int oldIndex, int newIndex) {
    if (oldIndex < newIndex) newIndex -= 1;
    final Note item = _notes.removeAt(oldIndex);
    _notes.insert(newIndex, item);
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Заметки',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/',
      onGenerateRoute: (RouteSettings settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const HomeScreen());
          case '/edit':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AddEditNoteScreen(
                index: args['index'],
                note: args['note'],
              ),
            );
          default:
            return MaterialPageRoute(
              builder: (_) => Scaffold(
                body: Center(child: Text('Маршрут ${settings.name} не найден')),
              ),
            );
        }
      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Мои заметки')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddNoteDialog(context),
        child: const Icon(Icons.add),
      ),
      body: Consumer<NotesProvider>(
        builder: (context, provider, child) {
          return ReorderableListView(
            padding: const EdgeInsets.all(8),
            children: [
              for (int index = 0; index < provider.notes.length; index++)
                _buildNoteItem(context, provider, index),
            ],
            onReorder: (oldIndex, newIndex) {
              provider.reorderNotes(oldIndex, newIndex);
            },
          );
        },
      ),
    );
  }

  Widget _buildNoteItem(BuildContext context, NotesProvider provider, int index) {
    final note = provider.notes[index];
    return ReorderableDragStartListener(
      key: ValueKey(note.title + index.toString()),
      index: index,
      child: _buildNoteContent(context, provider, index),
    );
  }

  Widget _buildNoteContent(BuildContext context, NotesProvider provider, int index) {
    final note = provider.notes[index];
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: InkWell(
        onTap: () => _viewNote(context, index),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(note.title, style: const TextStyle(fontSize: 18)),
                    const SizedBox(height: 4),
                    Text(
                      note.content,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.grey[700]),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.edit, color: Colors.blue),
                onPressed: () => _editNote(context, index),
              ),
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () => provider.deleteNote(index),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _viewNote(BuildContext context, int index) {
    final note = Provider.of<NotesProvider>(context, listen: false).notes[index];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(note.title),
        content: SingleChildScrollView(child: Text(note.content)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }

  void _editNote(BuildContext context, int index) {
    final provider = Provider.of<NotesProvider>(context, listen: false);
    final note = provider.notes[index];
    Navigator.pushNamed(
      context,
      '/edit',
      arguments: {'index': index, 'note': note},
    );
  }

  void _showAddNoteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AddNoteDialog(),
    );
  }
}

class AddNoteDialog extends StatefulWidget {
  @override
  _AddNoteDialogState createState() => _AddNoteDialogState();
}

class _AddNoteDialogState extends State<AddNoteDialog> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Новая заметка'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(labelText: 'Название'),
            autofocus: true,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _contentController,
            decoration: const InputDecoration(labelText: 'Содержание'),
            maxLines: 3,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Отмена'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_titleController.text.isNotEmpty) {
              Provider.of<NotesProvider>(context, listen: false).addNote(
                Note(
                  title: _titleController.text,
                  content: _contentController.text,
                ),
              );
              Navigator.pop(context);
            }
          },
          child: const Text('Добавить'),
        ),
      ],
    );
  }
}

class AddEditNoteScreen extends StatefulWidget {
  final int index;
  final Note note;

  const AddEditNoteScreen({
    super.key,
    required this.index,
    required this.note,
  });

  @override
  _AddEditNoteScreenState createState() => _AddEditNoteScreenState();
}

class _AddEditNoteScreenState extends State<AddEditNoteScreen> {
  late final TextEditingController _titleController;
  late final TextEditingController _contentController;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.note.title);
    _contentController = TextEditingController(text: widget.note.content);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактировать заметку'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveChanges,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Название'),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: TextField(
                controller: _contentController,
                decoration: const InputDecoration(labelText: 'Содержание'),
                maxLines: null,
                expands: true,
                keyboardType: TextInputType.multiline,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveChanges() {
    if (_titleController.text.isNotEmpty) {
      Provider.of<NotesProvider>(context, listen: false).updateNote(
        widget.index,
        Note(
          title: _titleController.text,
          content: _contentController.text,
        ),
      );
      Navigator.pop(context);
    }
  }
}